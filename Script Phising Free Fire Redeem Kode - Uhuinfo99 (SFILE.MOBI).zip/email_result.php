<?
$result = "email@gmail.com";
?>
